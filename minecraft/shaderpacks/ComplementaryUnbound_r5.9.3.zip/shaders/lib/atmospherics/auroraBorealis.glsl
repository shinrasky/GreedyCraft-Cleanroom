vec3 GetAuroraBorealis(vec3 viewPos, float VdotU, float dither) {
    #ifdef GC_TWILIGHT_FOREST
        float visibility = pow2((1.0 - sunVisibility) * (1.0 - rainFactor));
        if (VdotU <= 0.0 || visibility <= 0.0) return vec3(0.0);

        vec3 wpos = normalize(mat3(gbufferModelViewInverse) * viewPos);
        vec2 wind = vec2(frameTimeCounter * 0.00005);
        float gradientMix = dither / 8.0;
        float NdotUM = min(1.08 - VdotU, 1.0);
        NdotUM = 1.0 - pow2(pow2(NdotUM));
        vec3 aurora = vec3(0.0);
        vec3 auroraUp = pow(vec3(112.0, 80.0, 255.0) / 255.0, vec3(2.0));
        vec3 auroraDown = pow(vec3(80.0, 255.0, 180.0) / 255.0, vec3(2.0));

        for (int i = 0; i < 8; i++) {
            vec2 planeCoord = wpos.xz * ((8.0 * 0.75 + (i + dither) * 7.0 / 8.0) / wpos.y) * 0.004;
            vec2 coord = cameraPosition.xz * 0.00001 + planeCoord;
            float noise = texture2D(noisetex, coord * 0.175 + wind * 0.25).x;
            noise += texture2D(noisetex, coord * 0.04375 + wind * 0.15).x * 5.0;
            noise = max(1.0 - 1.5 / (1.0 - VdotU * 0.8) * abs(noise - 3.0) - 0.18, 0.0);

            if (noise > 0.0) {
                noise *= texture2D(noisetex, coord * 0.25 + wind * 0.25).x;
                noise *= 0.5 * texture2D(noisetex, coord + wind * 16.0).x + 0.75;
                noise = noise * noise * 3.0 / 8.0 * NdotUM;
                vec3 auroraColor = mix(auroraDown, auroraUp, pow(gradientMix, 0.4));
                aurora += noise * auroraColor * exp2(-6.0 * i / 8.0);
            }
            gradientMix += 1.0 / 8.0;
        }

        return aurora * visibility * 0.75;
    #else
    float visibility = sqrt1(clamp01(VdotU * 1.5 - 0.225)) - sunVisibility - rainFactor - maxBlindnessDarkness;
    visibility *= 1.0 - VdotU * 0.9;

    #if AURORA_CONDITION == 1 || AURORA_CONDITION == 3
        visibility -= moonPhase;
    #endif
    #if AURORA_CONDITION == 2 || AURORA_CONDITION == 3
        visibility *= inSnowy;
    #endif
    #if AURORA_CONDITION == 4
        visibility = max(visibility * inSnowy, visibility - moonPhase);
    #endif

    if (visibility > 0.0) {
        vec3 aurora = vec3(0.0);

        vec3 wpos = mat3(gbufferModelViewInverse) * viewPos;
             wpos.xz /= wpos.y;
        vec2 cameraPositionM = cameraPosition.xz * 0.0075;
             cameraPositionM.x += syncedTime * 0.04;

        #ifdef DEFERRED1
            int sampleCount = 25;
            int sampleCountP = sampleCount + 5;
        #else
            int sampleCount = 10;
            int sampleCountP = sampleCount + 10;
        #endif

        float ditherM = dither + 5.0;
        float auroraAnimate = frameTimeCounter * 0.001;
        for (int i = 0; i < sampleCount; i++) {
            float current = pow2((i + ditherM) / sampleCountP);

            vec2 planePos = wpos.xz * (0.8 + current) * 11.0 + cameraPositionM;
            #if AURORA_STYLE == 1
                planePos = floor(planePos) * 0.0007;

                float noise = texture2DLod(noisetex, planePos, 0.0).b;
                noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

                noise *= pow1_5(texture2DLod(noisetex, planePos * 100.0 + auroraAnimate, 0.0).b);
            #else
                planePos *= 0.0007;

                float noise = texture2DLod(noisetex, planePos, 0.0).r;
                noise = pow2(pow2(pow2(pow2(1.0 - 2.0 * abs(noise - 0.5)))));

                noise *= texture2DLod(noisetex, planePos * 3.0 + auroraAnimate, 0.0).b;
                noise *= texture2DLod(noisetex, planePos * 5.0 - auroraAnimate, 0.0).b;
            #endif

            float currentM = 1.0 - current;
            aurora += noise * currentM * mix(vec3(7.0, 2.2, 12.0), vec3(6.0, 16.0, 12.0), pow2(pow2(currentM)));
        }

        #if AURORA_STYLE == 1
            aurora *= 1.3;
        #else
            aurora *= 1.8;
        #endif

        #ifdef ATM_COLOR_MULTS
            aurora *= sqrtAtmColorMult; // C72380KD - Reduced atmColorMult impact on some things
        #endif

        return aurora * visibility / sampleCount;
    }

    return vec3(0.0);
    #endif
}
