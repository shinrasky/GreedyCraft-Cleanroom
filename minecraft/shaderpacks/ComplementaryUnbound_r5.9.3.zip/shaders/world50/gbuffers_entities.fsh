#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_ENTITIES

#include "/program/gbuffers_entities.glsl"
