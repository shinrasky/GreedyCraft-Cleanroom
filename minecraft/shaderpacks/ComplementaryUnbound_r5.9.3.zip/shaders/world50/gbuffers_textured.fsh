#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_TEXTURED

#include "/program/gbuffers_textured.glsl"
