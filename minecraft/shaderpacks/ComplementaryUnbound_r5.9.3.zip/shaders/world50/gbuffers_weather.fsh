#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_WEATHER

#include "/program/gbuffers_weather.glsl"
