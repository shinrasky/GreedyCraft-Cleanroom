#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE5

#include "/program/composite5.glsl"
