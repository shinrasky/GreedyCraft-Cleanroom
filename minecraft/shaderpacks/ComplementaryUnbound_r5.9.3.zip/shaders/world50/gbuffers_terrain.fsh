#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_TERRAIN

#include "/program/gbuffers_terrain.glsl"
