#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE7

#include "/program/composite7.glsl"
