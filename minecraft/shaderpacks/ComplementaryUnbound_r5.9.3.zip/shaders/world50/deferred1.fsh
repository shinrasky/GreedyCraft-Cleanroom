#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define DEFERRED1

#include "/program/deferred1.glsl"
