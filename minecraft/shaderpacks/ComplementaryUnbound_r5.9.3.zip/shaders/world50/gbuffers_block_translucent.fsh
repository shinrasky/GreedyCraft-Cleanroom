#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_BLOCK
#define GBUFFERS_BLOCK_TRANSLUCENT

#include "/program/gbuffers_block.glsl"
