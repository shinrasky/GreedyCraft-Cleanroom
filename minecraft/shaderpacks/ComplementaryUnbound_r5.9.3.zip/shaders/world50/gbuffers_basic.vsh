#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_BASIC

#include "/program/gbuffers_basic.glsl"
