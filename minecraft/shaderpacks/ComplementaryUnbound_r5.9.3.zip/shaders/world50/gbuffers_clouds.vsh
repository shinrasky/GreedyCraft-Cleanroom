#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_CLOUDS

#include "/program/gbuffers_clouds.glsl"
