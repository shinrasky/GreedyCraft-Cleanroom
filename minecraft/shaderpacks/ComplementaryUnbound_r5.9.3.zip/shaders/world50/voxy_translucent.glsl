#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_WORLD
#define VOXY_TRANSLUCENT

#include "/program/voxy_translucent.glsl"
