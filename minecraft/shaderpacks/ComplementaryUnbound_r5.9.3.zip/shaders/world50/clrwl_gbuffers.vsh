#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_TERRAIN
#define GBUFFERS_COLORWHEEL

#include "/program/gbuffers_terrain.glsl"
