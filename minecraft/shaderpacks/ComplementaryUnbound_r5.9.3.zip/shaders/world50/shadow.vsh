#version 400 compatibility

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define SHADOW

#include "/program/shadow.glsl"
