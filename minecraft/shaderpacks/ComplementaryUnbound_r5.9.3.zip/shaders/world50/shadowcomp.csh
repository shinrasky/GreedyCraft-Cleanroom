#version 430 compatibility

#define COMPUTE_SHADER
#define OVERWORLD
#define GC_ABYSSAL_WORLD
#define SHADOWCOMP

#include "/program/shadowcomp.glsl"
