#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_SPIDEREYES

#include "/program/gbuffers_spidereyes.glsl"
