#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE4

#include "/program/composite4.glsl"
