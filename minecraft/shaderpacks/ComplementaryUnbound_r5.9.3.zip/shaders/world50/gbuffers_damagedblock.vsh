#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_DAMAGEDBLOCK

#include "/program/gbuffers_damagedblock.glsl"
