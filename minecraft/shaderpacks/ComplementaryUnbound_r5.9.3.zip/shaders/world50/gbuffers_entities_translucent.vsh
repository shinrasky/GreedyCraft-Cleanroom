#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_TRANSLUCENT

#include "/program/gbuffers_entities.glsl"
