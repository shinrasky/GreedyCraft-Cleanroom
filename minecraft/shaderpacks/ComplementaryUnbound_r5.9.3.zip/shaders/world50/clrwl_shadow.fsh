#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"
