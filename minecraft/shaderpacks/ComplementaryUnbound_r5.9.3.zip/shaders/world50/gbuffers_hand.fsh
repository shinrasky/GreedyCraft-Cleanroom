#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_HAND

#include "/program/gbuffers_hand.glsl"
