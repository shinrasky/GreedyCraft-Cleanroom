#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_BEACONBEAM

#include "/program/gbuffers_beaconbeam.glsl"
