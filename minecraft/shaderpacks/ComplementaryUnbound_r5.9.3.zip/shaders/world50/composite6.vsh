#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE6

#include "/program/composite6.glsl"
