#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE3

#include "/program/composite3.glsl"
