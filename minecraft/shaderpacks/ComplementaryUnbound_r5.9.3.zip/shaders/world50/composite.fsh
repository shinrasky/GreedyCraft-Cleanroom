#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define COMPOSITE

#include "/program/composite.glsl"
