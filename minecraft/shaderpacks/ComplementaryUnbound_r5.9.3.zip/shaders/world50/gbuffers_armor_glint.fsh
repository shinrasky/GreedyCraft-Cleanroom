#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_ARMOR_GLINT

#include "/program/gbuffers_armor_glint.glsl"
