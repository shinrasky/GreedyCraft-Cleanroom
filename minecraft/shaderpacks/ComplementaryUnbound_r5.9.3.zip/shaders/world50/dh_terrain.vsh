#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define DH_TERRAIN

#include "/program/dh_terrain.glsl"
