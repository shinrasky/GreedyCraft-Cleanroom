#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_WORLD
#define VOXY_OPAQUE

#include "/program/voxy_opaque.glsl"
