#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define SHADOW

#include "/program/shadow.glsl"
