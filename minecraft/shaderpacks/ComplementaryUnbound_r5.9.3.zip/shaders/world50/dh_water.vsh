#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define DH_WATER

#include "/program/dh_water.glsl"
