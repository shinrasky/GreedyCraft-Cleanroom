#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_50
#define GBUFFERS_WATER
#define GBUFFERS_COLORWHEEL_TRANSLUCENT

#include "/program/gbuffers_water.glsl"
