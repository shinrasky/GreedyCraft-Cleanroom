#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_51
#define COMPOSITE1

#include "/program/composite1.glsl"
