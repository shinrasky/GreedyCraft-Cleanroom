#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_51
#define COMPOSITE3

#include "/program/composite3.glsl"
