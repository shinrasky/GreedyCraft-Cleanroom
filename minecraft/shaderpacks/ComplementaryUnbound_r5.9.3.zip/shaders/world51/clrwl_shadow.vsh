#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_51
#define SHADOW
#define SHADOW_COLORWHEEL

#include "/program/shadow.glsl"
