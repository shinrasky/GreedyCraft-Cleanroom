#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define GC_ABYSSAL_51
#define GBUFFERS_DAMAGEDBLOCK
#define GBUFFERS_COLORWHEEL

#include "/program/gbuffers_damagedblock.glsl"
