#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GC_ABYSSAL_51
#define COMPOSITE

#include "/program/composite.glsl"
